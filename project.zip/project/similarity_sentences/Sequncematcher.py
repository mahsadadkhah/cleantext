import numpy as np  
from difflib import SequenceMatcher
from Clean_main.py import *

text1 = """
علی و محسن به همراه نادر به مدرسه در روزهای پاییزی میروند.
زهرا به مدرسه همراه خواهرش رفت ولی محمد به مدرسه نرفت.
غذا سرد است.
"""
text2 = """
علی و حسن به همراه نادری در روزهای پاییزی به مدرسه رفتند
زهرا به دانشگاه می رود.
 چه روز زیبایی است.
"""


alpha = fix_half_space(text1)
beta = remove_consecutive_duplicates(alpha)
gamma = verb_tokenizer(beta)
epsilon = modify_sentences(gamma)
clean_text1 = word_tokener(epsilon)

print("cleaned text1:", clean_text1)


a = fix_half_space(text2)
b = remove_consecutive_duplicates(a)
c = verb_tokenizer(b)
d = modify_sentences(c)
clean_text2 = word_tokener(d)
print("cleaned text2:", clean_text2)

def calculate_similarity_matrix(a, b, threshold=0.7):  
    # Define the similarity function  
    def similar(x, y):  
        return SequenceMatcher(None, x, y).ratio()  
  
    # Initialize an empty matrix filled with zeros  
    matrix_a_b = np.zeros((len(a), len(b)))  
  
    # Fill in the matrix with similarity values  
    for i in range(len(a)):  
        for j in range(len(b)):  
            matrix_a_b[i, j] = similar(a[i], b[j])  
  
    # Print the matrix for similarity between a and b  
    print("Matrix between a and b:")  
    print(matrix_a_b)  
  
    # Replace elements less than the threshold with zero  
    thresholded_matrix = np.where(matrix_a_b < threshold, 0, matrix_a_b)  
  
    # Calculate the mean of upper threshold elements in each row, handling division by zero  
    row_sums = np.sum(thresholded_matrix, axis=1)  
    row_counts = np.count_nonzero(thresholded_matrix, axis=1)  
    row_means = np.where(row_counts == 0, 0.0, row_sums / row_counts)  
  
    # Reshape the result to have one column  
    new_matrix = row_means.reshape(-1, 1)  
 
    count = 0 
    total = 0 
 
    for sublist in new_matrix: 
        for element in sublist: 
            if element != 0: 
                count += 1 
                total += element 
 
    mean = total / count if count > 0 else 0 
 
 
    # Print the final matrix  
 
    print("\nMatrix after thresholding and calculating means:")  
    print(new_matrix)  
    print("Count:", count) 
    print("Mean:", mean) 
    return mean



comparison_matrix = []

for sentence1 in clean_text1:
    row = []
    for sentence2 in clean_text2:
        similarity_score = calculate_similarity_matrix(sentence1, sentence2)
        row.append(similarity_score)
    comparison_matrix.append(row)

print("last mayrix: ")
print(np.array(comparison_matrix))



